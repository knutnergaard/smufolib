"""where SMuFL meets UFO

"""
from smufolib._version import __version__
from smufolib.objects.engravingDefaults import EngravingDefaults
from smufolib.objects.font import Font
from smufolib.objects.glyph import Glyph
from smufolib.objects.layer import Layer
from smufolib.objects.range import Range
from smufolib.objects.smufl import Smufl
from smufolib.request import Request
from smufolib.request import URLWarning
