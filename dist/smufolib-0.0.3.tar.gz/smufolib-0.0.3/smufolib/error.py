"""Error module for SMufoLib."""


class URLWarning(Warning):
    """URL connection failure warning."""
